/* 
   Exemplo de cria��o de threads com POSIX Threads (Pthreads).
   Este exemplo cria duas threads que executam concorrentemente a fun��o mostraCidade.
*/

#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// A fun��o a seguir � executada por cada uma das threads.
// Em Pthreads, a fun��o deve:
// - Retornar void*
// - Receber um argumento do tipo void* (ponteiro gen�rico)
//
// Caso seja necess�rio passar mais de um dado para a thread,
// deve-se utilizar estruturas (struct).
void* mostraCidade(void* arg) {
    const char* nome = (const char*) arg; // convers�o de void* para const char*

    int aux1, aux2, aux3, count;

    // Define a quantidade de itera��es conforme o nome da cidade
    if (strcmp(nome, "Santa Maria") == 0)
        count = 50;
    else
        count = 100;

    // Loop de execu��o da thread
    for (aux1 = 0; aux1 < count; aux1++) {
        printf("%d %s\n", aux1, nome);

        // Simula um atraso sem bloquear a thread (busy wait)
        for (aux2 = rand() / 10000; aux2 > 0; aux2--)
            for (aux3 = 10; aux3 > 0; aux3--);
    }

    pthread_exit(NULL); // finaliza a thread
}

// A fun��o main representa a thread principal do programa.
// A partir dela, criamos novas threads com pthread_create.
int main() {

    pthread_t thUm, thDois; // uma vari�vel para cada thread

    // Cria��o das threads:
    // 1� argumento: identificador da thread
    // 2� argumento: atributos (NULL = padr�o)
    // 3� argumento: fun��o a ser executada
    // 4� argumento: par�metro passado para a fun��o (void*)
    pthread_create(&thUm, NULL, mostraCidade, (void*) "Santa Maria");
    pthread_create(&thDois, NULL, mostraCidade, (void*) "Porto Alegre");

    // A thread principal espera o t�rmino das threads criadas
    // Como n�o precisamos do valor de retorno, usamos NULL
    pthread_join(thUm, NULL);
    pthread_join(thDois, NULL);

    printf("Fim da thread principal\n");

    return 0;
}
