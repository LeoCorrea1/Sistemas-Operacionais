/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package leitoresescritores;

/**
 *
 * @author gspal
 */
public class Acao {
    
    private String variavelCompartilhada;
    private String escreveuJa;
    
    public Acao(String variavelCompartilhada,String escreveuJa){
        
        this.variavelCompartilhada = variavelCompartilhada;
        this.escreveuJa = escreveuJa;
        
    }
    
    public synchronized void ler(int id) throws InterruptedException{
        
        if (this.escreveuJa == null){
            wait();
        }
        this.escreveuJa = null;
        System.out.println("Leitor "+id+"-> leu: "+this.variavelCompartilhada);
        notifyAll();
        
    }
    
    public synchronized void escrever(String conteudo) throws InterruptedException{
        
       while (escreveuJa != null){ 
            wait();
        }
        
        this.escreveuJa = "S";
        System.out.println("Escrevendo: "+conteudo);
        this.variavelCompartilhada = conteudo;
        notifyAll();
        
    }
    
}
