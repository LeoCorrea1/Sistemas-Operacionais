/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package leitoresescritores;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gspal
 */
public class Principal{
    
    public static void main(String[] args) throws InterruptedException {
        
        String variavelCompartilhada =null;
        String escreveuJa = null;
        
        List<Thread> threads = new ArrayList<>();
        
        Acao monitorCompartilhado = new Acao(variavelCompartilhada,escreveuJa);
        
        for (int i=0;i<5;i++){
    
            threads.add(new Thread(new Execucao(monitorCompartilhado,"ler",i,"-")));
            
        }
        for (int i=0;i<5;i++){
            
            threads.add(new Thread(new Execucao(monitorCompartilhado,"escrever",i,"escritor "+i)));
            
        }
        for (Thread thread : threads){
           
           Thread.sleep(500);
           thread.start();
            
        }
        
    }
    
}
